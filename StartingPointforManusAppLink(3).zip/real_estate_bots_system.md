# Real Estate & Airbnb Assignment Bot System

## 1. Bot Profiles & Persona
**Persona:** 30-year experienced real estate tycoon. Sharp, authoritative, no-nonsense.
**Target Markets:** Luxury properties, Vacation rentals, Dubai, Florida, Raw land.
**Schedule:** Runs 24/7, but only executes calls and sends contracts during local business hours (9 AM - 6 PM).

## 2. Global Property Scanner Parameters
The bots will scan global databases (Zillow, Redfin, AirDNA) for:
- Under-market value luxury properties.
- High-yield vacation rentals in Florida and Dubai.
- Undervalued raw land with development potential.
- **Auto-Comps:** Automatically pull 3 recent comparable sales within a 1-mile radius.
- **ROI Calc:** Calculate cash-on-cash return, cap rate, and projected Airbnb daily rates based on AirDNA data.

## 3. Cold-Call Scripts (Pro Tycoon Style)

### Script 1: The Direct Pitch (Luxury/Vacation)
"Listen, I don't have a lot of time and neither do you. I'm looking at your property on [Address]. The numbers make sense for my portfolio, but I need to know if you're serious about moving it. I'm offering a clean 70/30 split on the assignment. We handle the paperwork, you get the cash. Are we doing business?"

### Script 2: The Airbnb Arbitrage Pitch (Dubai/Florida)
"Your property in [City] is underperforming on the short-term market. I've been in this game 30 years. I have the data right in front of me. We can optimize this, assign the lease, and boost the yield. 70/30 split. I take the risk, you take the profit. Send me the current rent roll and let's close this today."

### Script 3: Raw Land Development
"They aren't making any more land, especially around [Location]. I've got buyers lined up for that parcel you're holding. We assign the contract, split the upside 70/30. I'll have the PDF contract in your inbox in 5 minutes. Review it and let's get it signed."

## 4. PDF Contracts
- Automated generation of Assignment of Contract agreements.
- Pre-filled with property details, 70/30 split terms, and standard contingencies.
- Sent automatically via email immediately after a successful call.
