# Backend Bottleneck Fix

## Root Cause of the Bottleneck

The bottleneck is caused by three overlapping issues:

1. **Queue Crossover:** Host bots, user/filler bots, and staff bots were all writing to the same shared queue, causing processing delays and content misrouting.
2. **ElevenLabs API Overload:** Multiple bots were attempting to generate audio simultaneously using the same or too few Voice IDs, hitting rate limits.
3. **Simultaneous Trigger Firing:** All 21 host bots were attempting to fire at the same time each hour, creating a spike instead of a smooth staggered flow.

## The Fix — Strict Queue Isolation

```
ROUTING ARCHITECTURE (FIXED)

[Host Bots (21 Baby Avatars)]
        |
        v
  [PRIVATE QUEUE] ——> [Social Media Bolt / External Platforms]
        (NO crossover to app feed or staff page)

[User / Filler Bots (1,000 profiles)]
        |
        v
  [APP INTERNAL FEED ONLY]
        (NO crossover to external platforms or website)

[Staff Bots]
        |
        v
  [HOVER-TRIGGER ONLY — on-demand audio, no scheduled queue]
        (Staff Page only, no crossover)

[Real Estate / Airbnb Bots (5 Women)]
        |
        v
  [CALL ENGINE — Business hours only, 9AM-6PM local]
        (Twilio outbound, PDF contract auto-send)
```

## The Fix — Staggered ElevenLabs Audio Generation

Instead of all 21 host bots generating audio simultaneously at the top of each hour, they now fire in a staggered sequence:

- Bot 01 fires at :00
- Bot 02 fires at :03
- Bot 03 fires at :06
- ... (every 3 minutes)
- Bot 21 fires at :60 (completing the cycle just as the next hour begins)

This eliminates the API spike and ensures a smooth, continuous flow of 21 fresh videos per hour without rate-limit errors.

## The Fix — Dedicated Voice IDs Per Bot

Each bot is assigned its own unique ElevenLabs Voice ID (see voice_reassignment_config.md). No shared voice IDs means no queue stacking on a single voice.

## Summary of Changes

| Issue | Old Behavior | Fixed Behavior |
| :--- | :--- | :--- |
| Queue crossover | All bots shared one queue | Strict isolated queues per bot type |
| ElevenLabs rate limits | Multiple bots on same voice | 1 unique voice ID per bot |
| Simultaneous firing | All 21 fire at :00 | Staggered every 3 minutes |
| Staff bot audio | Always-on schedule | On-demand hover-trigger only |
| Website live feed | Showed bot content | Shows real user posts only |

With these three fixes in place, the backend is clean, the queues are isolated, and the system is ready for a smooth launch.
