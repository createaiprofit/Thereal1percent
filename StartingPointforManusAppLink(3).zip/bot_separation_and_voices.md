# Bot Roster Separation & Voice Reassignment Plan

To ensure a clean launch and fix the backend bottleneck, we must strictly separate the bots into their designated roles and queues, as requested.

## 1. Bot Segregation & Routing

Based on the system architecture, bots must be isolated to prevent queue crossover (which causes bottlenecks):

### Staff Bots (The Team)
- **Role:** Internal app operations, bios, and specific departmental tasks.
- **Location:** "Staff Page" only.
- **Interaction:** Introduce themselves by reading their bios when a user hovers over them.
- **Groups:**
  - *Finance Group:* Dedicated finance prompts.
  - *The Syndicate:* Dedicated assignments and prompts.
  - *Chief Investment Officer:* Designated as "THE HAMMER".

### Host Bots (Marketing Avatars / Baby Bots)
- **Role:** External marketing, affiliate plugs, Machiavelli quotes, AI leverage tricks.
- **Location:** "Host Page" and **Private Queue only**.
- **Routing:** Removed entirely from user-side feeds, news feeds, and shared queues. Routed *exclusively* to a private queue, which then pushes to external platforms (Social Media Bolt).
- **Population:** All 21 Baby Bots.

### User Bots (Filler Bots)
- **Role:** App engagement (liking, commenting, DMing real users).
- **Routing:** Locked strictly to the app's internal social feed. NO crossover to external marketing queues or the website live-feed preview.

### Specialized Groups
- **Chameleon Bots:** Execute chameleon bot prompts.
- **Cast Stars & Go Stars:** Execute mini-series prompts.
- **Real Estate & Airbnb Bots:** (The 5 new women bots) Dedicated exclusively to real estate assignments, auto-comps, ROI calculations, and 70/30 cold-call pitches.

## 2. Voice Reassignment (ElevenLabs)

To fix the audio generation bottleneck, voices must be assigned distinctly to avoid rate-limit clashes on a single voice ID.

| Bot Category | Voice Profile (ElevenLabs) | Assignment Strategy |
| :--- | :--- | :--- |
| **Staff Bots** | Professional, clear, departmental tone. "The Hammer" gets a deep, authoritative voice. | 1 unique voice per staff member for hover-bios. |
| **Host Bots (Baby Avatars)** | Sharp, commanding, Machiavellian. No soft talk. | 21 distinct sharp/commanding voices to handle the hourly Social Bolt video generation. |
| **Real Estate Sharks** | 30-year experienced tycoon, no-nonsense, aggressive. | 5 distinct authoritative female voices for the cold-call scripts. |

## 3. Fixing the Backend Bottleneck

The bottleneck is caused by queue crossover. By strictly enforcing the routing rules above:
1. **Host Bots** stop clogging the internal app feed and are isolated to the Private Queue for external rendering.
2. **User/Filler Bots** stop attempting to push to external platforms.
3. **ElevenLabs API** calls are distributed across multiple Voice IDs rather than queuing up behind a single default voice.

*Next Step:* I will prepare the specific routing logic to ensure the Staff Bots are isolated first, followed by the voice assignments.
