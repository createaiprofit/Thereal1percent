# ElevenLabs Voice Reassignment Configuration

Each bot category gets its own distinct voice ID to eliminate API queue bottlenecks. Voices are spread across the roster so no single voice ID is overloaded.

## Staff Bots — Voice Assignments

| Bot Name / Role | Voice Profile | ElevenLabs Voice Style |
| :--- | :--- | :--- |
| THE HAMMER (Chief Investment Officer) | Deep, authoritative, commanding | "Adam" or "Arnold" — deep male, zero softness |
| Finance Group Bot 1 | Professional, sharp, analytical | "Daniel" — clear British professional |
| Finance Group Bot 2 | Confident, measured | "Josh" — calm American authority |
| Finance Group Bot 3 | Assertive, fast-paced | "Antoni" — energetic, sharp |
| Syndicate Bot 1 | Low, powerful, strategic | "Clyde" — deep Southern authority |
| Syndicate Bot 2 | Smooth, persuasive | "Dave" — conversational but sharp |
| Syndicate Bot 3 | Intense, focused | "Fin" — crisp and direct |

> **Hover-Bio Rule:** Each staff bot reads their own bio on hover using their assigned voice. No shared voice IDs.

## Host Bots (21 Baby Avatar Bots) — Voice Assignments

All 21 host bots get distinct sharp, commanding Machiavellian voices. Voices rotate to prevent rate-limit stacking.

| Bot # | Voice Profile | ElevenLabs Voice Style |
| :--- | :--- | :--- |
| Bot 01 | Sharp, cold, powerful female | "Bella" — crisp, commanding |
| Bot 02 | Smooth tycoon male | "Adam" — deep authority |
| Bot 03 | Fierce, no-nonsense female | "Elli" — fast, sharp |
| Bot 04 | Luxury male, slow burn | "Arnold" — deep, deliberate |
| Bot 05 | Young sharp female | "Rachel" — clear, assertive |
| Bot 06 | Older tycoon male | "Clyde" — gravelly authority |
| Bot 07 | Seductive power female | "Domi" — low, commanding |
| Bot 08 | Fast-talking hustler male | "Antoni" — energetic |
| Bot 09 | Ice cold female | "Glinda" — precise, cold |
| Bot 10 | Boardroom male | "Josh" — professional |
| Bot 11 | Street-smart female | "Freya" — sharp, urban |
| Bot 12 | Old money male | "Daniel" — British authority |
| Bot 13 | Confident young female | "Charlotte" — clear, bold |
| Bot 14 | Aggressive male | "Fin" — intense |
| Bot 15 | Luxury lifestyle female | "Sarah" — smooth, confident |
| Bot 16 | Strategic male | "Dave" — calm, calculated |
| Bot 17 | Power broker female | "Alice" — crisp, decisive |
| Bot 18 | Mentor male | "Bill" — warm authority |
| Bot 19 | Sharp analyst female | "Matilda" — fast, precise |
| Bot 20 | Closer male | "George" — smooth, persuasive |
| Bot 21 | Machiavelli anchor female | "Lily" — cold, poised |

## Real Estate & Airbnb Bots (5 Women Bots) — Voice Assignments

| Bot Name | Voice Profile | ElevenLabs Voice Style |
| :--- | :--- | :--- |
| RE Bot 1 | Luxury broker, authoritative | "Charlotte" — bold, clear |
| RE Bot 2 | Airbnb specialist, fast | "Elli" — sharp, energetic |
| RE Bot 3 | Dubai market expert | "Domi" — commanding, low |
| RE Bot 4 | Florida vacation rental | "Rachel" — warm but assertive |
| RE Bot 5 | Raw land tycoon | "Bella" — cold, precise |

## Bottleneck Fix — API Call Distribution

To prevent ElevenLabs rate-limit bottlenecks, the following rules apply:
- No two bots share the same Voice ID.
- Host bots generate audio in a staggered queue (1 per minute per bot, not all 21 simultaneously).
- Staff bots only generate audio on hover-trigger events, not on a schedule.
- Real estate bots generate audio only during active call sessions (business hours only).
