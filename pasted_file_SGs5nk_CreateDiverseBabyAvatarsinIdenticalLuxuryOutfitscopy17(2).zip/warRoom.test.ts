import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock the db module
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
}));

// Mock the schema imports
vi.mock("../drizzle/schema", () => ({
  deals: {},
  callLogs: {},
  botPerformance: {},
  warRoomAlerts: {},
}));

describe("warRoom router structure", () => {
  it("exports warRoomRouter with expected sub-routers", async () => {
    const { warRoomRouter } = await import("./routers/warRoom");
    expect(warRoomRouter).toBeDefined();
    // The router should be an object (tRPC router)
    expect(typeof warRoomRouter).toBe("object");
  });

  it("warRoomRouter has deals, calls, bots, alerts, overview keys", async () => {
    const { warRoomRouter } = await import("./routers/warRoom");
    const routerDef = (warRoomRouter as any)._def;
    expect(routerDef).toBeDefined();
    // tRPC v11 stores procedures in _def.procedures or _def.record
    const procedures = routerDef.procedures ?? routerDef.record ?? {};
    const keys = Object.keys(procedures);
    // Should have nested keys like deals.list, deals.create, etc.
    const hasDeals = keys.some(k => k.startsWith("deals"));
    const hasCalls = keys.some(k => k.startsWith("calls"));
    const hasBots = keys.some(k => k.startsWith("bots"));
    const hasAlerts = keys.some(k => k.startsWith("alerts"));
    const hasOverview = keys.some(k => k === "overview");
    expect(hasDeals).toBe(true);
    expect(hasCalls).toBe(true);
    expect(hasBots).toBe(true);
    expect(hasAlerts).toBe(true);
    expect(hasOverview).toBe(true);
  });
});

describe("warRoom deal stage validation", () => {
  it("valid stages are accepted", () => {
    const validStages = ["cold", "pitched", "negotiating", "assigned", "closed", "lost"];
    validStages.forEach(stage => {
      expect(validStages.includes(stage)).toBe(true);
    });
  });

  it("invalid stage is not in valid list", () => {
    const validStages = ["cold", "pitched", "negotiating", "assigned", "closed", "lost"];
    expect(validStages.includes("unknown")).toBe(false);
  });
});

describe("warRoom call outcome validation", () => {
  it("all call outcomes are valid", () => {
    const validOutcomes = ["no_answer", "voicemail", "interested", "not_interested", "callback", "pitched", "assigned"];
    validOutcomes.forEach(outcome => {
      expect(typeof outcome).toBe("string");
      expect(outcome.length).toBeGreaterThan(0);
    });
  });
});

describe("warRoom alert severity levels", () => {
  it("severity levels map to correct colors", () => {
    const SEVERITY_COLOR: Record<string, string> = {
      info: "rgba(59,130,246,0.2)",
      warning: "rgba(234,179,8,0.2)",
      critical: "rgba(248,113,113,0.2)",
    };
    expect(SEVERITY_COLOR.info).toBe("rgba(59,130,246,0.2)");
    expect(SEVERITY_COLOR.warning).toBe("rgba(234,179,8,0.2)");
    expect(SEVERITY_COLOR.critical).toBe("rgba(248,113,113,0.2)");
  });
});

describe("warRoom bot conversion rate calculation", () => {
  it("calculates conversion rate correctly", () => {
    const callsWeek = 100;
    const assignedCount = 5;
    const conversionRate = callsWeek > 0
      ? ((assignedCount / callsWeek) * 100).toFixed(2)
      : "0.00";
    expect(conversionRate).toBe("5.00");
  });

  it("returns 0.00 when no calls made", () => {
    const callsWeek = 0;
    const assignedCount = 0;
    const conversionRate = callsWeek > 0
      ? ((assignedCount / callsWeek) * 100).toFixed(2)
      : "0.00";
    expect(conversionRate).toBe("0.00");
  });

  it("handles high conversion rate", () => {
    const callsWeek = 10;
    const assignedCount = 3;
    const conversionRate = callsWeek > 0
      ? ((assignedCount / callsWeek) * 100).toFixed(2)
      : "0.00";
    expect(conversionRate).toBe("30.00");
  });
});

describe("warRoom fee formatting", () => {
  it("formats fee correctly with null fallback", () => {
    const feesGenerated: string | null = null;
    const formatted = parseFloat(feesGenerated ?? "0").toLocaleString();
    expect(formatted).toBe("0");
  });

  it("formats fee correctly with value", () => {
    const feesGenerated = "125000.00";
    const formatted = parseFloat(feesGenerated).toLocaleString();
    expect(formatted).toBe("125,000");
  });
});
