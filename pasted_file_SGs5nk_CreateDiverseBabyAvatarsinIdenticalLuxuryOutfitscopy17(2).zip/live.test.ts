import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the database module
vi.mock("./db", () => ({
  getDb: vi.fn().mockResolvedValue(null),
}));

function makeCtx(role: "user" | "admin" = "user"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "manus",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("live.getMessages", () => {
  it("returns empty array when db is unavailable", async () => {
    const caller = appRouter.createCaller(makeCtx());
    const result = await caller.live.getMessages();
    expect(Array.isArray(result)).toBe(true);
    expect(result).toHaveLength(0);
  });
});

describe("live.sendMessage", () => {
  it("throws when db is unavailable", async () => {
    const caller = appRouter.createCaller(makeCtx());
    await expect(caller.live.sendMessage({ message: "Hello" })).rejects.toThrow("Database unavailable");
  });

  it("rejects empty message", async () => {
    const caller = appRouter.createCaller(makeCtx());
    await expect(caller.live.sendMessage({ message: "" })).rejects.toThrow();
  });

  it("rejects message over 300 chars", async () => {
    const caller = appRouter.createCaller(makeCtx());
    const longMsg = "a".repeat(301);
    await expect(caller.live.sendMessage({ message: longMsg })).rejects.toThrow();
  });
});

describe("live.clearMessages", () => {
  it("throws FORBIDDEN for non-admin users", async () => {
    const caller = appRouter.createCaller(makeCtx("user"));
    await expect(caller.live.clearMessages()).rejects.toThrow("Forbidden");
  });

  it("throws database unavailable for admin when db is null", async () => {
    const caller = appRouter.createCaller(makeCtx("admin"));
    await expect(caller.live.clearMessages()).rejects.toThrow("Database unavailable");
  });
});
