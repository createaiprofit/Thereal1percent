from PIL import Image
import numpy as np
from sklearn.cluster import KMeans

img = Image.open("/home/ubuntu/upload/ecv-logo-v2.png").convert("RGBA")
data = np.array(img)

# Only opaque pixels
mask = data[:, :, 3] > 200
pixels = data[mask][:, :3].astype(float)

# Sample 5000 pixels for clustering
np.random.seed(42)
idx = np.random.choice(len(pixels), min(5000, len(pixels)), replace=False)
sample = pixels[idx]

# K-means with 6 clusters to find dominant palette
kmeans = KMeans(n_clusters=6, random_state=42, n_init=10)
kmeans.fit(sample)
centers = kmeans.cluster_centers_.astype(int)
labels = kmeans.labels_
counts = np.bincount(labels)

# Sort by count descending
order = np.argsort(counts)[::-1]
print("ECV Logo — 6 dominant colors (by frequency):")
for i, idx in enumerate(order):
    r, g, b = centers[idx]
    hex_color = '#{:02X}{:02X}{:02X}'.format(r, g, b)
    brightness = (r + g + b) / 3
    print(f"  {i+1}. {hex_color}  RGB({r},{g},{b})  brightness={brightness:.0f}  count={counts[idx]}")

# Pick the 4 most visually distinct
print("\n--- FINAL 4 ECV PALETTE COLORS ---")
sorted_centers = [centers[order[i]] for i in range(6)]

# Background: darkest
bg = sorted(sorted_centers, key=lambda c: c.mean())[0]
# Highlight/white: brightest
highlight = sorted(sorted_centers, key=lambda c: c.mean())[-1]
# Silver: mid neutral (R≈G≈B)
neutrals = [c for c in sorted_centers if abs(int(c[0])-int(c[1])) < 30 and abs(int(c[1])-int(c[2])) < 30 and 80 < c.mean() < 220]
silver = neutrals[0] if neutrals else sorted_centers[2]
# Accent: most saturated non-neutral
def saturation(c):
    return max(c) - min(c)
accents = [c for c in sorted_centers if saturation(c) > 20 and not (abs(int(c[0])-int(c[1])) < 20 and abs(int(c[1])-int(c[2])) < 20)]
accent = sorted(accents, key=saturation, reverse=True)[0] if accents else sorted_centers[1]

for name, c in [("1. Background (deep black-blue)", bg), ("2. Highlight (bright white/silver)", highlight), ("3. Silver (brushed metal)", silver), ("4. Accent (chrome/blue tint)", accent)]:
    r, g, b = int(c[0]), int(c[1]), int(c[2])
    print(f"  {name}: #{r:02X}{g:02X}{b:02X}  RGB({r},{g},{b})")
