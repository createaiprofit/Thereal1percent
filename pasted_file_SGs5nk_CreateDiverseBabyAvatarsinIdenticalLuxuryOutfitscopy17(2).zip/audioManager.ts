/**
 * Global Audio Manager — ONE audio instance across the entire app.
 * All pages must import playVoice / stopVoice from here.
 * Never create `new Audio()` directly in any page or component.
 */

const _state: { current: HTMLAudioElement | null } = { current: null };

export function playVoice(url: string, volume = 0.85): void {
  // Stop whatever is playing first
  if (_state.current) {
    _state.current.pause();
    _state.current.currentTime = 0;
    _state.current = null;
  }
  const audio = new Audio(url);
  audio.volume = Math.min(1, Math.max(0, volume));
  audio.play().catch(() => {
    // Autoplay blocked — silently ignore, user must interact first
  });
  _state.current = audio;
  // Auto-clean reference when track ends
  audio.addEventListener("ended", () => {
    if (_state.current === audio) _state.current = null;
  });
}

export function stopVoice(): void {
  if (_state.current) {
    _state.current.pause();
    _state.current.currentTime = 0;
    _state.current = null;
  }
}

export function isPlaying(): boolean {
  return _state.current !== null && !_state.current.paused;
}

// ─── WEB SPEECH TTS ───────────────────────────────────────────────────────────
// Speaks text using the browser's built-in SpeechSynthesis API.
// voiceIndex: 0=default, 1=deep male, 2=high female, 3=accented, etc.
// Returns the utterance so callers can listen to onend.
export function speakText(
  text: string,
  opts: { pitch?: number; rate?: number; volume?: number; lang?: string } = {}
): SpeechSynthesisUtterance | null {
  if (typeof window === "undefined" || !window.speechSynthesis) return null;
  window.speechSynthesis.cancel(); // stop any current speech
  const u = new SpeechSynthesisUtterance(text);
  u.pitch = opts.pitch ?? 0.85;
  u.rate = opts.rate ?? 0.88;
  u.volume = opts.volume ?? 0.95;
  u.lang = opts.lang ?? "en-US";
  window.speechSynthesis.speak(u);
  return u;
}

export function stopSpeech(): void {
  if (typeof window !== "undefined" && window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
}

export function isSpeaking(): boolean {
  return typeof window !== "undefined" &&
    window.speechSynthesis?.speaking === true;
}
