import re

CDN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663435070666/UKZTwoEXuGkRzDU2B5gMpQ"

# Map host id -> new CDN image URL (cigar/glasses v2 from avatar_cards)
HOST_IMGS = {
    "black":       f"{CDN}/cap_strategist_v2_f104276d.png",
    "russian":     f"{CDN}/cap_ghost_v2_2589fde8.png",
    "russian_v2":  f"{CDN}/cap_architect_v2_1d466824.png",
    "italian":     f"{CDN}/cap_consigliere_v2_b1444fd6.png",
    "italian_v2":  f"{CDN}/cap_don_v2_bb5cfe73.png",
    "mexican":     f"{CDN}/cap_builder_v2_1e230cc5.png",
    "romanian":    f"{CDN}/cap_phantom_v2_53971652.png",
    "romanian_v2": f"{CDN}/cap_tactician_v2_c70de2bc.png",
    "arab":        f"{CDN}/cap_sheikh_v2_845db823.png",
    "indian":      f"{CDN}/cap_visionary_v2_4f0ab78a.png",
    "la_hollywood":f"{CDN}/cap_director_v2_57b45dab.png",
    "nyc":         f"{CDN}/cap_broker_v2_a64ecdfc.png",
    "atlanta":     f"{CDN}/cap_king_v2_9871cfc4.png",
    "black_v2b":   f"{CDN}/cap_closer_v2_2a44e1da.png",
    # operator gets miami/vegas slot
    "miami":       f"{CDN}/cap_operator_v2_6fdd94e3.png",
    "vegas":       f"{CDN}/cap_operator_v2_6fdd94e3.png",
}

path = "/home/ubuntu/createaiprofit/client/src/pages/Home.tsx"
with open(path, "r") as f:
    content = f.read()

# Parse HOSTS array and replace img values per id
def replace_host_img(content, host_id, new_url):
    # Find the block for this id and replace its img line
    pattern = rf'(id:\s*"{re.escape(host_id)}".*?img:\s*")[^"]*(")'
    replacement = rf'\g<1>{new_url}\g<2>'
    new_content, count = re.subn(pattern, replacement, content, flags=re.DOTALL)
    if count:
        print(f"  Updated {host_id}: {new_url}")
    else:
        print(f"  WARNING: id '{host_id}' not found")
    return new_content

for host_id, url in HOST_IMGS.items():
    content = replace_host_img(content, host_id, url)

with open(path, "w") as f:
    f.write(content)

print("Done — all HOSTS img URLs updated to cigar/glasses v2 avatars.")
