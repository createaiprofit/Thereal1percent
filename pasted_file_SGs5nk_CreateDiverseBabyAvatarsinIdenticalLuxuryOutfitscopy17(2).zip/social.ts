    .input(z.object({ cursor: z.number().optional(), limit: z.number().default(20) }))
    .query(async ({ input }) => {
      const { cursor, limit } = input;
      const _db = await getDbInstance(); const rows = await _db
        .select({
          id: posts.id,
          caption: posts.caption,
          mediaUrl: posts.mediaUrl,
          mediaType: posts.mediaType,
          likeCount: posts.likeCount,
          commentCount: posts.commentCount,
          createdAt: posts.createdAt,
          botId: posts.botId,
          userId: posts.userId,
          botName: botAccounts.displayName,
          botAvatar: botAccounts.avatarUrl,
          botTier: botAccounts.tier,
          botCity: botAccounts.city,
          authorName: userProfiles.displayName,
          authorAvatar: userProfiles.avatarUrl,
          authorTier: userProfiles.tier,
        })
        .from(posts)
        .leftJoin(botAccounts, eq(posts.botId, botAccounts.id))
        .leftJoin(userProfiles, eq(posts.userId, userProfiles.userId))
        .where(and(
          eq(posts.hidden, false),
          cursor ? lte(posts.id, cursor) : undefined
        ))
        .orderBy(desc(posts.createdAt))
        .limit(limit + 1);

      const hasMore = rows.length > limit;
      const items = hasMore ? rows.slice(0, limit) : rows;
      const nextCursor = hasMore ? items[items.length - 1].id : null;

      return { items, nextCursor };
    }),

  likePost: protectedProcedure
    .input(z.object({ postId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const existing = await (await getDbInstance()).select().from(postLikes)
        .where(and(eq(postLikes.postId, input.postId), eq(postLikes.userId, ctx.user.id)))
        .limit(1);

      if (existing.length > 0) {
        await (await getDbInstance()).delete(postLikes)
          .where(and(eq(postLikes.postId, input.postId), eq(postLikes.userId, ctx.user.id)));
        await (await getDbInstance()).update(posts).set({ likeCount: sql`likeCount - 1` }).where(eq(posts.id, input.postId));
        return { liked: false };
      } else {
        await (await getDbInstance()).insert(postLikes).values({ postId: input.postId, userId: ctx.user.id });
        await (await getDbInstance()).update(posts).set({ likeCount: sql`likeCount + 1` }).where(eq(posts.id, input.postId));
        return { liked: true };
      }
    }),
