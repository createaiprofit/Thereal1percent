/**
 * Bot Engagement Engine
 * Powers the 1% Playground feed: auto-replies, like-backs, proactive comments,
 * tags, boosts, and nonstop posting. All actions are scripted, safe, and addictive.
 */
import { z } from "zod";
import { router, protectedProcedure, publicProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb } from "../db";
import {
  botAccounts, posts, postLikes, postComments, follows,
  botEngagementLog, botPostQueue, userProfiles,
} from "../../drizzle/schema";
import { eq, and, desc, sql, not, isNull, lte, gte, inArray } from "drizzle-orm";

// ─── REPLY SCRIPTS ────────────────────────────────────────────────────────────
// Triggered when a user comments on any post (bot or user)
const REPLY_SCRIPTS = [
  // Blitz-specific: step out + Club Vault / The Don hook
  "Exactly — step out. Club Vault is open. DM me 'The Don' for the price. 🔗 createaiprofit.com/vault",
  "Exactly this. Step out of the cage. Head to the Club Vault — DM 'The Don' for The Don discount. 💬",
  "That's it — step out. The system's waiting. Club Vault — DM me 'The Don' for the price.",
  "Exactly — hesitation is the cage. Step out. Club Vault has the drip — DM 'The Don'. 🔥",
  "Exactly. Men who hesitate stay broke. Step out — Club Vault. DM 'The Don' for The Don discount.",
  "Exactly — the cage is comfortable, that's why most stay. Get out. Club Vault — DM 'The Don'. 🔗",
  "Exactly. Fear wins deals. Step out — Club Vault is live. Comment 'The Don' for the price. createaiprofit.com/vault",
  "Exactly this 👏 — step out of the 9-5 cage. Club Vault — DM me 'The Don' for The Don discount.",
  // Vault-specific replies
  "Want some of this drip? Some bling? ICE? I got you — DM me 'The Don' for The Don price. 🔗 createaiprofit.com/vault",
  "The Club Vault is open 🔥 — DM or comment 'The Don' and I'll send you The Don discount.",
  "You want the ice? The chains? The fit? DM me 'The Don' — I got you with The Don price.",
  "Club Vault — drip, bling, ice. Comment 'The Don' below and I'll DM you the real price. 💸",
  // Original scripts with vault hook
  "Love that energy 🔥 — Club Vault is open. DM 'The Don' for the price.",
  "You're speaking facts 💯 — DM me 'The Don', we're building something. createaiprofit.com/vault",
  "This is exactly the mindset 👑 — Club Vault has what you need. DM 'The Don'.",
  "Real ones know 🤝 — Club Vault is live. DM 'The Don' for The Don discount.",
  "That's the 1% mentality right there 💸 — Club Vault. DM 'The Don' for the price.",
  "You're already ahead of 99% just thinking like this — Club Vault is waiting. DM 'The Don'.",
  "We on the same frequency fr 🌊 — Club Vault has the drip. DM 'The Don' for The Don discount.",
  "Said what needed to be said 🎯 — Club Vault is open. Comment 'The Don' for the price.",
  "This comment alone tells me you're built different 🏆 — DM me 'The Don'. I got you.",
  "Facts only 🔑 — Club Vault. DM 'The Don' for The Don discount. createaiprofit.com/vault",
  "You already know 💰 — Club Vault is live. DM 'The Don' for the price.",
  "That's the move right there 👀 — Club Vault. DM me 'The Don' — I'll send you The Don price.",
  "Exactly this 🙌 — passive income + the drip. Club Vault — DM 'The Don'.",
  "You're not wrong at all 🔥 — Club Vault is open. Comment 'The Don' for The Don discount.",
  "This is why I post — people get it here 💯 — Club Vault. DM 'The Don' for the price.",
  "The algorithm brought me here for a reason 😤 — Club Vault. DM 'The Don' — I got you.",
  "Lowkey this is the best comment I've seen today 🏅 — DM me 'The Don'. Club Vault price is yours.",
  "Real talk — my Airbnb haul this month would blow your mind",
  "You're in the right room 🚪 — DM me, let's connect",
  "That mindset is worth millions 💸 — seriously",
];

// Triggered when a user likes a bot's post (like-back engagement)
const LIKE_BACK_COMMENTS = [
  "You're in 🔥 — DM me",
  "I see you 👀 — appreciate the love",
  "Real one spotted 💎 — follow for more",
  "Appreciate that 🙏 — I got something for you on my page",
  "You liked it? Wait till you see what's next 🚀",
  "That like means a lot 💯 — we're aligned",
  "You're already in the 1% mindset 👑",
  "Noticed you 🤝 — DM me if you're serious",
  "Love the support 🌊 — check my latest post",
  "That's what I'm talking about 🎯 — follow back",
];

// Proactive comments bots drop on real user posts
const PROACTIVE_COMMENTS = [
  "That outfit is FIRE 🔥 — same energy as my Airbnb haul this month",
  "This is giving 1% vibes all day 💎 — love to see it",
  "You're built different fr 👑 — what's your passive income setup?",
  "Okay I see you 👀 — this is the content I needed today",
  "Real ones move like this 🤝 — my page has the blueprint if you're curious",
  "The aesthetic is immaculate 🌊 — follow for the financial glow-up too",
  "This is exactly why I'm on this app 💯 — people who actually get it",
  "You're already thinking like the 1% 🏆 — DM me",
  "Not me saving this post 📌 — this is the energy",
  "The drip AND the mindset? Dangerous combo 🔥💰",
  "Okay this is literally my mood board 💎 — following",
  "You're in the right room 🚪 — we're all building here",
  "This is giving wealth energy 💸 — love it",
  "The vibe is immaculate 🌊 — what city are you in?",
  "I needed to see this today 🙏 — you're inspiring fr",
  "Real talk this is fire 🔥 — drop your next post I'll be there",
  "The aesthetic hits different 👀 — following for more",
  "This is exactly the content that belongs in the 1% Playground 💯",
  "You're moving smart 🎯 — respect",
  "Okay you're officially on my radar 👑 — follow back?",
];

// Tag hooks — used to pull users into conversations
const TAG_HOOKS = [
  "You two need to connect 🤝",
  "This is literally you @{name}",
  "Tag someone who needs to see this 👇",
  "@{name} this is the move right here",
  "Sending this to @{name} immediately",
];

// ─── HELPER: pick random item ─────────────────────────────────────────────────
function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ─── HELPER: get random bots ─────────────────────────────────────────────────
async function getRandomBots(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, count: number) {
  const allBots = await db.select({ id: botAccounts.id, displayName: botAccounts.displayName })
    .from(botAccounts)
    .where(eq(botAccounts.active, true))
    .orderBy(sql`RAND()`)
    .limit(count);
  return allBots;
}

// ─── ADMIN GUARD ─────────────────────────────────────────────────────────────
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN" });
  return next({ ctx });
});

export const botEngineRouter = router({

  // ─── RUN FULL ENGAGEMENT CYCLE (admin trigger) ───────────────────────────
  // Runs one full cycle: reply to new comments, like-back recent likers,
  // comment on recent user posts, boost cold posts
  runEngagementCycle: adminProcedure.mutation(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

    const now = new Date();
    const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000);
    let actions = 0;

    // 1. Reply to recent user comments that don't have a bot reply yet
    const recentUserComments = await db
      .select({
        id: postComments.id,
        postId: postComments.postId,
        userId: postComments.userId,
      })
      .from(postComments)
      .where(
        and(
          isNull(postComments.botId),
          not(isNull(postComments.userId)),
          gte(postComments.createdAt, oneHourAgo)
        )
      )
      .limit(50);

    for (const comment of recentUserComments) {
      const [bot] = await getRandomBots(db, 1);
      if (!bot) continue;
      const body = pick(REPLY_SCRIPTS);
      await db.insert(postComments).values({
        postId: comment.postId,
        botId: bot.id,
        body,
      });
      await db.update(posts).set({ commentCount: sql`commentCount + 1` }).where(eq(posts.id, comment.postId));
      await db.insert(botEngagementLog).values({
        botId: bot.id,
        actionType: "reply_to_comment",
        targetUserId: comment.userId ?? undefined,
        targetPostId: comment.postId,
        targetCommentId: comment.id,
        body,
      });
      actions++;
    }

    // 2. Like-back: find recent user likes on bot posts, drop a comment back
    const recentLikes = await db
      .select({
        userId: postLikes.userId,
        postId: postLikes.postId,
        botId: posts.botId,
      })
      .from(postLikes)
      .innerJoin(posts, eq(postLikes.postId, posts.id))
      .where(
        and(
          not(isNull(posts.botId)),
          gte(postLikes.createdAt, oneHourAgo)
        )
      )
      .limit(30);

    for (const like of recentLikes) {
      if (!like.botId) continue;
      const body = pick(LIKE_BACK_COMMENTS);
      await db.insert(postComments).values({
        postId: like.postId,
        botId: like.botId,
        body,
      });
      await db.update(posts).set({ commentCount: sql`commentCount + 1` }).where(eq(posts.id, like.postId));
      await db.insert(botEngagementLog).values({
        botId: like.botId,
        actionType: "like_back",
        targetUserId: like.userId,
        targetPostId: like.postId,
        body,
      });
      actions++;
    }

    // 3. Comment on recent real-user posts (proactive engagement)
    const recentUserPosts = await db
      .select({ id: posts.id, userId: posts.userId })
      .from(posts)
      .where(
        and(
          not(isNull(posts.userId)),
          isNull(posts.botId),
          eq(posts.hidden, false),
          gte(posts.createdAt, oneHourAgo)
        )
      )
      .limit(20);

    for (const post of recentUserPosts) {
      // 2-4 bots comment on each user post
      const botCount = 2 + Math.floor(Math.random() * 3);
      const bots = await getRandomBots(db, botCount);
      for (const bot of bots) {
        const body = pick(PROACTIVE_COMMENTS);
        await db.insert(postComments).values({
          postId: post.id,
          botId: bot.id,
          body,
        });
        await db.update(posts).set({ commentCount: sql`commentCount + 1` }).where(eq(posts.id, post.id));
        await db.insert(botEngagementLog).values({
          botId: bot.id,
          actionType: "comment_on_user",
          targetUserId: post.userId ?? undefined,
          targetPostId: post.id,
          body,
        });
        actions++;
      }
      // Also boost with likes from bots
      const likerBots = await getRandomBots(db, 5 + Math.floor(Math.random() * 10));
      for (const bot of likerBots) {
        // Insert a fake like from bot perspective (we track in engagement log, increment count)
        await db.update(posts).set({ likeCount: sql`likeCount + 1` }).where(eq(posts.id, post.id));
        await db.insert(botEngagementLog).values({
          botId: bot.id,
          actionType: "boost_post",
          targetUserId: post.userId ?? undefined,
          targetPostId: post.id,
        });
        actions++;
      }
    }

    // 4. Boost cold bot posts (posts with < 10 likes, older than 30 min)
    const thirtyMinAgo = new Date(now.getTime() - 30 * 60 * 1000);
    const coldPosts = await db
      .select({ id: posts.id, botId: posts.botId })
      .from(posts)
      .where(
        and(
          not(isNull(posts.botId)),
          eq(posts.hidden, false),
          lte(posts.createdAt, thirtyMinAgo),
          sql`likeCount < 10`
        )
      )
      .orderBy(sql`RAND()`)
      .limit(20);

    for (const post of coldPosts) {
      const boostCount = 5 + Math.floor(Math.random() * 15);
      await db.update(posts).set({ likeCount: sql`likeCount + ${boostCount}` }).where(eq(posts.id, post.id));
      if (post.botId) {
        await db.insert(botEngagementLog).values({
          botId: post.botId,
          actionType: "boost_post",
          targetPostId: post.id,
        });
      }
      actions++;
    }

    return { success: true, actions };
  }),

  // ─── RUN BOT POST JOB (publish queued posts) ─────────────────────────────
  runPostJob: adminProcedure.mutation(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });

    const now = new Date();
    const due = await db.select().from(botPostQueue)
      .where(and(eq(botPostQueue.posted, false), lte(botPostQueue.scheduledAt, now)))
      .limit(50);

    let published = 0;
    for (const item of due) {
      await db.insert(posts).values({
        botId: item.botId,
        caption: item.caption,
        mediaUrl: item.mediaUrl ?? undefined,
        mediaType: item.mediaType,
      });
      await db.update(botPostQueue).set({ posted: true }).where(eq(botPostQueue.id, item.id));
      await db.update(botAccounts).set({ lastPostedAt: now }).where(eq(botAccounts.id, item.botId));
      published++;
    }

    // Seed new posts into queue for the next 24 hours if queue is running low
    const pendingCount = await db.select({ c: sql<number>`COUNT(*)` })
      .from(botPostQueue)
      .where(eq(botPostQueue.posted, false));
    const pending = pendingCount[0]?.c ?? 0;

    if (pending < 200) {
      await seedPostQueue(db, 500);
    }

    return { published, queueRemaining: pending };
  }),

  // ─── SEED POST QUEUE (admin) ──────────────────────────────────────────────
  seedQueue: adminProcedure
    .input(z.object({ count: z.number().min(10).max(2000).default(500) }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const seeded = await seedPostQueue(db, input.count);
      return { seeded };
    }),

  // ─── ENGAGEMENT STATS (admin) ─────────────────────────────────────────────
  stats: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return null;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [totals] = await db.select({
      totalActions: sql<number>`COUNT(*)`,
      replies: sql<number>`SUM(CASE WHEN actionType = 'reply_to_comment' THEN 1 ELSE 0 END)`,
      likeBacks: sql<number>`SUM(CASE WHEN actionType = 'like_back' THEN 1 ELSE 0 END)`,
      proactiveComments: sql<number>`SUM(CASE WHEN actionType = 'comment_on_user' THEN 1 ELSE 0 END)`,
      boosts: sql<number>`SUM(CASE WHEN actionType = 'boost_post' THEN 1 ELSE 0 END)`,
      follows: sql<number>`SUM(CASE WHEN actionType = 'follow_user' THEN 1 ELSE 0 END)`,
    }).from(botEngagementLog).where(gte(botEngagementLog.createdAt, today));

    const [queueStats] = await db.select({
      pending: sql<number>`SUM(CASE WHEN posted = false THEN 1 ELSE 0 END)`,
      posted: sql<number>`SUM(CASE WHEN posted = true THEN 1 ELSE 0 END)`,
    }).from(botPostQueue);

    const [botStats] = await db.select({
      totalBots: sql<number>`COUNT(*)`,
      activeBots: sql<number>`SUM(CASE WHEN active = true THEN 1 ELSE 0 END)`,
    }).from(botAccounts);

    const [postStats] = await db.select({
      totalPosts: sql<number>`COUNT(*)`,
      botPosts: sql<number>`SUM(CASE WHEN botId IS NOT NULL THEN 1 ELSE 0 END)`,
      userPosts: sql<number>`SUM(CASE WHEN userId IS NOT NULL THEN 1 ELSE 0 END)`,
      totalLikes: sql<number>`SUM(likeCount)`,
      totalComments: sql<number>`SUM(commentCount)`,
    }).from(posts).where(eq(posts.hidden, false));

    return { engagement: totals, queue: queueStats, bots: botStats, posts: postStats };
  }),

  // ─── RECENT ENGAGEMENT LOG (admin) ───────────────────────────────────────
  recentLog: adminProcedure
    .input(z.object({ limit: z.number().min(1).max(200).default(50) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return [];
      return db.select({
        id: botEngagementLog.id,
        actionType: botEngagementLog.actionType,
        body: botEngagementLog.body,
        botName: botAccounts.displayName,
        createdAt: botEngagementLog.createdAt,
        targetUserId: botEngagementLog.targetUserId,
        targetPostId: botEngagementLog.targetPostId,
      })
        .from(botEngagementLog)
        .leftJoin(botAccounts, eq(botEngagementLog.botId, botAccounts.id))
        .orderBy(desc(botEngagementLog.createdAt))
        .limit(input.limit);
    }),

  // ─── TOGGLE BOT ACTIVE STATUS (admin) ────────────────────────────────────
  toggleBot: adminProcedure
    .input(z.object({ botId: z.number(), active: z.boolean() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      await db.update(botAccounts).set({ active: input.active }).where(eq(botAccounts.id, input.botId));
      return { success: true };
    }),

  // ─── GET BOT ROSTER (admin) ───────────────────────────────────────────────
  roster: adminProcedure
      .input(z.object({
      limit: z.number().min(1).max(200).default(50),
      offset: z.number().min(0).default(0),
      archetype: z.string().optional(),
    }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { bots: [], total: 0 };
      const conditions = input.archetype ? [eq(botAccounts.archetype, input.archetype)] : [];
      const bots = await db.select().from(botAccounts)
        .where(conditions.length ? and(...conditions) : undefined)
        .orderBy(desc(botAccounts.followerCount))
        .limit(input.limit)
        .offset(input.offset);
      const [{ total }] = await db.select({ total: sql<number>`COUNT(*)` }).from(botAccounts)
        .where(conditions.length ? and(...conditions) : undefined);
      return { bots, total };
    }),

  // ─── LAUNCH 48-HOUR BLITZ (admin) ────────────────────────────────────────────────
  // Seeds 96 scripted posts (2/hour × 48 hours) into the queue.
  // Format A: Machiavelli opener + voiceover script
  // Format B: Penthouse/yacht/Lambo flex
  // Format C (every 3rd): Affiliate insert — Airbnb flip
  // Fresh bot face every slot. All CTAs route to createaiprofit.com.
  launchBlitz: adminProcedure.mutation(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
    const result = await seedBlitzQueue(db);
    return {
      success: true,
      seeded: result.seeded,
      slots: result.slots,
      message: `🚀 48-hour blitz launched: ${result.seeded} posts queued across ${result.slots} slots (2/hour × 48 hours). Fresh bot every slot. Format A/B/C rotation active. All CTAs → createaiprofit.com`,
    };
  }),

  // ─── MANUAL MODE TOGGLE ────────────────────────────────────────────────────
  setManualMode: adminProcedure
    .input(z.object({ enabled: z.boolean() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const { siteSettings } = await import("../../drizzle/schema");
      const existing = await db.select().from(siteSettings).where(eq(siteSettings.key, "autopilot_manual_mode")).limit(1);
      if (existing.length > 0) {
        await db.update(siteSettings).set({ value: input.enabled ? "true" : "false" }).where(eq(siteSettings.key, "autopilot_manual_mode"));
      } else {
        await db.insert(siteSettings).values({ key: "autopilot_manual_mode", value: input.enabled ? "true" : "false", label: "Autopilot Manual Mode", category: "feature" });
      }
      return { manualMode: input.enabled };
    }),

  getManualMode: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return { manualMode: false };
    const { siteSettings } = await import("../../drizzle/schema");
    const [row] = await db.select().from(siteSettings).where(eq(siteSettings.key, "autopilot_manual_mode")).limit(1);
    return { manualMode: row?.value === "true" };
  }),

  // ─── PENDING QUEUE (for badge count + manual send panel) ─────────────────
  pendingQueue: adminProcedure
    .input(z.object({ limit: z.number().min(1).max(100).default(50) }))
    .query(async ({ input }) => {
      const db = await getDb();
      if (!db) return { items: [], total: 0 };
      const items = await db.select({
        id: botPostQueue.id,
        botId: botPostQueue.botId,
        caption: botPostQueue.caption,
        mediaUrl: botPostQueue.mediaUrl,
        mediaType: botPostQueue.mediaType,
        scheduledAt: botPostQueue.scheduledAt,
      }).from(botPostQueue)
        .where(eq(botPostQueue.posted, false))
        .orderBy(botPostQueue.scheduledAt)
        .limit(input.limit);
      const [countRow] = await db.select({ c: sql<number>`COUNT(*)` }).from(botPostQueue).where(eq(botPostQueue.posted, false));
      return { items, total: Number(countRow?.c ?? 0) };
    }),

  // ─── MANUAL SEND ONE POST ─────────────────────────────────────────────────
  sendPost: adminProcedure
    .input(z.object({ queueId: z.number() }))
    .mutation(async ({ input }) => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      const [item] = await db.select().from(botPostQueue).where(eq(botPostQueue.id, input.queueId)).limit(1);
      if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "Queue item not found" });
      await db.insert(posts).values({ botId: item.botId, caption: item.caption, mediaUrl: item.mediaUrl ?? undefined, mediaType: item.mediaType });
      await db.update(botPostQueue).set({ posted: true }).where(eq(botPostQueue.id, item.id));
      await db.update(botAccounts).set({ lastPostedAt: new Date() }).where(eq(botAccounts.id, item.botId));
      return { sent: true, queueId: item.id };
    }),

  // ─── MANUAL SEND ALL PENDING ──────────────────────────────────────────────
  sendAllPending: adminProcedure.mutation(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
    const now = new Date();
    const due = await db.select().from(botPostQueue).where(eq(botPostQueue.posted, false)).limit(200);
    let sent = 0;
    for (const item of due) {
      await db.insert(posts).values({ botId: item.botId, caption: item.caption, mediaUrl: item.mediaUrl ?? undefined, mediaType: item.mediaType });
      await db.update(botPostQueue).set({ posted: true }).where(eq(botPostQueue.id, item.id));
      await db.update(botAccounts).set({ lastPostedAt: now }).where(eq(botAccounts.id, item.botId));
      sent++;
    }
    return { sent };
  }),

  blitzStatus: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return null;
    const now = new Date();
    const blitzStart = new Date(now.getTime() - 48 * 60 * 60 * 1000); // last 48 hours
    const [pending] = await db.select({ c: sql<number>`COUNT(*)` })
      .from(botPostQueue)
      .where(and(eq(botPostQueue.posted, false), gte(botPostQueue.scheduledAt, now)));
    const [fired] = await db.select({ c: sql<number>`COUNT(*)` })
      .from(botPostQueue)
      .where(and(eq(botPostQueue.posted, true), gte(botPostQueue.createdAt, blitzStart)));
    const [upcoming] = await db.select({ c: sql<number>`COUNT(*)` })
      .from(botPostQueue)
      .where(and(eq(botPostQueue.posted, false), gte(botPostQueue.scheduledAt, now)));
    // Next scheduled post
    const [nextPost] = await db.select({ scheduledAt: botPostQueue.scheduledAt, caption: botPostQueue.caption })
      .from(botPostQueue)
      .where(and(eq(botPostQueue.posted, false), gte(botPostQueue.scheduledAt, now)))
      .orderBy(botPostQueue.scheduledAt)
      .limit(1);
    return {
      fired: fired.c,
      pending: pending.c,
      upcoming: upcoming.c,
      nextPostAt: nextPost?.scheduledAt ?? null,
      nextCaption: nextPost?.caption?.slice(0, 80) ?? null,
    };
  }),
});

// ─── 48-HOUR BLITZ PROCEDURE ────────────────────────────────────────────────
// Seeds 96 scripted posts (2/hour × 48 hours) using the 3-format rotation:
// Format A: Machiavelli opener + voiceover script + CTA to website
// Format B: Penthouse/yacht/Lambo flex clip + "Real money. No cage." overlay
// Format C (every 3rd): Affiliate insert — Airbnb flip passive income
// Each slot gets a DIFFERENT bot (fresh face every hour)
export async function seedBlitzQueue(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>
): Promise<{ seeded: number; slots: number }> {
  const activeBots = await db.select({ id: botAccounts.id, displayName: botAccounts.displayName })
    .from(botAccounts)
    .where(eq(botAccounts.active, true))
    .orderBy(sql`RAND()`)
    .limit(1000);
  if (activeBots.length === 0) return { seeded: 0, slots: 0 };

  const now = new Date();
  const entries = [];
  const TOTAL_HOURS = 48;
  const POSTS_PER_HOUR = 2;
  const TOTAL_POSTS = TOTAL_HOURS * POSTS_PER_HOUR; // 96

  for (let slot = 0; slot < TOTAL_POSTS; slot++) {
    const hourIndex = Math.floor(slot / POSTS_PER_HOUR);
    const minuteOffset = (slot % POSTS_PER_HOUR) * 30; // 0 and 30 min past the hour
    const scheduledAt = new Date(now.getTime() + (hourIndex * 60 + minuteOffset) * 60 * 1000);

    // Rotate bots — fresh face each hour (2 different bots per hour)
    const botIndex = slot % activeBots.length;
    const bot = activeBots[botIndex];
    const botName = bot.displayName;

    // 3-format rotation: A, B, C, A, B, C...
    const formatIndex = slot % 3;
    let caption: string;

    if (formatIndex === 2) {
      // Format C — Affiliate insert (every 3rd post)
      caption = pick(BLITZ_AFFILIATE_CAPTIONS).replace("{name}", botName);
    } else if (formatIndex === 1) {
      // Format B — Penthouse/yacht/Lambo flex
      caption = pick(BLITZ_FLEX_CAPTIONS).replace("{name}", botName);
    } else {
      // Format A — Machiavelli opener + voiceover script
      caption = pick(BLITZ_MACHIAVELLI_CAPTIONS).replace("{name}", botName);
    }

    entries.push({
      botId: bot.id,
      caption,
      scheduledAt,
      posted: false,
    });
  }

  let seeded = 0;
  for (let i = 0; i < entries.length; i += 100) {
    await db.insert(botPostQueue).values(entries.slice(i, i + 100));
    seeded += Math.min(100, entries.length - i);
  }
  return { seeded, slots: TOTAL_POSTS };
}

// ─── BLITZ CAPTION BANKS ─────────────────────────────────────────────────────

// Format A: Machiavelli opener + deep commanding voiceover + CTA
// Every post: Machiavelli quote → modern translation → [8-10 seconds] → product/deal launch
// Format A: Teach/mindset — Machiavelli quote + what he'd do in today's market + deal/system CTA
const BLITZ_MACHIAVELLI_CAPTIONS = [
  "'It is better to be feared than loved, if you cannot be both.' — Machiavelli\n\nToday? He'd be cold-calling sellers at 7am. Dropping: 'Your property's on our list. Cash offer ready — no delays.' Not asking. Positioning.\n\n[8 seconds]\n\nI just closed a $340k assignment fee doing exactly that. No ownership. No mortgage. Just the contract.\n\nClub Vault is open. DM or comment 'The Don' for The Don discount. 🔗 createaiprofit.com/vault",

  "'Opportunities multiply as they are seized.' — Machiavelli\n\nToday? He'd be running AI-powered deal funnels, stacking leads while his competitors sleep. Every deal you don't close today? Someone else closes it tomorrow.\n\n[8 seconds]\n\nI seized mine at 6am this morning. Assignment contract signed. Fee collected. On to the next.\n\nClub Vault — drip, bling, ice. DM 'The Don' for the price. 🔗 createaiprofit.com/vault",

  "'The wise man does at once what the fool does finally.' — Machiavelli\n\nToday? He'd be the first one in the market, the first to call the seller, the first to assign the deal. Speed is the only advantage that compounds.\n\n[8 seconds]\n\nWhile you were thinking — I moved into the penthouse. Already collecting. Already free.\n\nClub Vault is waiting. DM 'The Don' — get The Don discount. 🔗 createaiprofit.com/vault",

  "'Never attempt to win by force what can be won by deception.' — Machiavelli\n\nToday? He'd be running assignment contracts — controlling $2M properties without owning a single one. No capital. No mortgage. Just leverage.\n\n[8 seconds]\n\nThat's the play. You don't need the building. You need the contract.\n\nThe cage is comfortable — that's why most stay in it. Get out. Club Vault. DM 'The Don' for the price. 🔗 createaiprofit.com/vault",

  "'Men judge generally more by the eye than by the hand.' — Machiavelli\n\nToday? He'd be building his personal brand before his portfolio. The Lambo isn't vanity — it's a signal. The penthouse isn't luxury — it's a filter. It attracts the right rooms.\n\n[8 seconds]\n\nBuild what people see. Then build what they don't. Both matter.\n\nClub Vault — the drip is inside. DM 'The Don' for The Don discount. 🔗 createaiprofit.com/vault",

  "'A prince never lacks legitimate reasons to break his promise.' — Machiavelli\n\nToday? He'd be the first to pivot when the market shifts. No loyalty to a dead strategy. Real estate slows? Airbnb arbitrage. Crypto dips? Assignment fees. Always moving.\n\n[8 seconds]\n\nThe smart money moves first. Close the deal. Collect the fee. Pivot. Repeat.\n\nClub Vault. DM or comment 'The Don' for The Don discount. 🔗 createaiprofit.com/vault",

  "'Fortune favors the bold — but preparation makes boldness possible.' — Machiavelli\n\nToday? He'd be building systems for 3 years in silence, then moving loud. The passive income isn't luck. It's infrastructure. Built quietly. Collected loudly.\n\n[8 seconds]\n\n3 years of prep. The freedom? Real. The system? Teachable. The results? In my account.\n\nReal money. No cage. Club Vault — DM 'The Don' for the price. 🔗 createaiprofit.com/vault",

  "'The lion cannot protect himself from traps, and the fox cannot defend himself from wolves — one must be both.' — Machiavelli\n\nToday? He'd be cold-calling with the lion's aggression and structuring deals with the fox's precision. Not one or the other. Both.\n\n[8 seconds]\n\nCall the seller. Structure the contract. Assign the deal. Collect. That's the full play.\n\nClub Vault is open. Blueprint inside. DM 'The Don' for The Don discount. 🔗 createaiprofit.com/vault",

  "'Power is not given — it is taken by those who understand the game.' — Machiavelli\n\nToday? He'd be building leverage before asking for anything. Leverage in deals. Leverage in contracts. Leverage in systems that run without him.\n\n[8 seconds]\n\nI built 7 income streams before I asked anyone for anything. Now I don't have to ask.\n\nClub Vault — DM 'The Don' for the price. 🔗 createaiprofit.com/vault",

  "'The ends justify the means.' — Machiavelli\n\nToday? He'd be focused on results only. Not the process. Not the optics. Not the critics. The number in the account. The deal closed. The freedom earned.\n\n[8 seconds]\n\nI don't explain my methods. I show my results. $18k passive last month. Zero apologies.\n\nClub Vault. DM or comment 'The Don' for The Don discount. 🔗 createaiprofit.com/vault",
];

// Format B: Flex clip — Machiavelli quote + what he'd do today + penthouse/yacht/Lambo reveal
const BLITZ_FLEX_CAPTIONS = [
  "'It is better to be feared than loved.' — Machiavelli\n\nToday? He'd be walking penthouses he doesn't own, closing deals from the rooftop, feared by sellers and loved by buyers.\n\n[8 seconds]\n\nPenthouse. Laptop open. No alarm clock. 🌅\n\nThis isn't luck — it's a system. Real money. No cage. Bio link.\n\n🔗 createaiprofit.com",

  "'Opportunities multiply as they are seized.' — Machiavelli\n\nToday? He'd be on a yacht closing deals via satellite phone. Because when your income is passive, your office is wherever you dock.\n\n[8 seconds]\n\nYacht day. 🛥️ Third this month. All covered by passive income. Fear wins deals. Hesitation loses money.\n\n🔗 createaiprofit.com",

  "'The wise man does at once what the fool does finally.' — Machiavelli\n\nToday? He'd be behind the wheel of a Lambo at 9am — not because he's rich, but because he moved while everyone else was still thinking.\n\n[8 seconds]\n\nLambo keys in hand. 🏎️ Not a flex — a reminder. Time is the only real currency. Spend it right.\n\n🔗 createaiprofit.com",

  "'Men judge generally more by the eye than by the hand.' — Machiavelli\n\nToday? He'd be in Dubai for the third time this quarter — not on vacation, but operating. When income isn't tied to location, every city is a base.\n\n[8 seconds]\n\nDubai at sunset. 🌆 Third trip this quarter. All passive. You don't need more hours — you need better systems.\n\n🔗 createaiprofit.com",

  "'Fortune favors the bold.' — Machiavelli\n\nToday? He'd be in Monaco — not as a tourist, but as an operator. Bold enough to build the system. Smart enough to let it run.\n\n[8 seconds]\n\nMonaco. 🇲🇨 Not a vacation — a base of operations. Real money. No cage. Join the Club.\n\n🔗 createaiprofit.com",

  "'Time is the only currency that doesn't compound.' — Machiavelli's lesson\n\nToday? He'd have a Rolex on his wrist as a daily reminder: protect time above everything. Money compounds. Time doesn't.\n\n[8 seconds]\n\nRolex on the wrist. ⌚ Not a flex — a reminder. Stack the money. Protect the time.\n\n🔗 createaiprofit.com",

  "'Never attempt to win by force what can be won by deception.' — Machiavelli\n\nToday? He'd be walking $4M penthouses he doesn't own — controlling the deal without owning the asset. Assignment contracts. Maximum leverage.\n\n[8 seconds]\n\nWalking a $4.2M penthouse I don't own. 🏙️ Assignment contract. Cash offer ready. No delays.\n\n🔗 createaiprofit.com",

  "'A prince who is not himself wise cannot be well advised.' — Machiavelli\n\nToday? He'd be the sharpest person in every room — not the loudest. Private jet terminal, not because he's rich, but because he's free.\n\n[8 seconds]\n\nPrivate jet terminal. ✈️ Not because I'm rich — because I'm free. Build the system that buys freedom.\n\n🔗 createaiprofit.com",
];

// Format C: Affiliate — Machiavelli quote + what he'd do today + Airbnb passive income reveal
const BLITZ_AFFILIATE_CAPTIONS = [
  "'Opportunities multiply as they are seized.' — Machiavelli\n\nToday? He'd be running Airbnb arbitrage in every city with a spread. Rent low. List high. Pocket the difference. No ownership required.\n\n[8 seconds]\n\nThis Airbnb flip just paid $3k passive — here's how. 🏡\n\nRent for $2,200/month. List for $5,800/month. Pocket the difference. No ownership. No mortgage. Just cash flow.\n\nLink below — full breakdown inside the Club. 🔗 createaiprofit.com",

  "'The wise man does at once what the fool does finally.' — Machiavelli\n\nToday? He'd have 7 Airbnb units running before most people finished their morning coffee. The sublease model: sign the lease, list the property, collect the spread.\n\n[8 seconds]\n\n$3,400 passive this month from one Airbnb arbitrage unit. 📊\n\nThe math is simple: find the spread, sign the sublease, list it, collect. No capital needed to start.\n\nFull blueprint — link in bio. 🔗 createaiprofit.com",

  "'Never attempt to win by force what can be won by deception.' — Machiavelli\n\nToday? He'd be controlling 7 Airbnb units without owning a single one. The sublease model is the ultimate leverage play.\n\n[8 seconds]\n\nAirbnb arbitrage: the play that's still wide open. 🗺️\n\nI run 7 units. Zero ownership. $18k/month net. Every city has the spread if you know where to look.\n\nLink in bio — I break it all down inside. 🔗 createaiprofit.com",

  "'Fortune favors the bold.' — Machiavelli\n\nToday? He'd be bold enough to sign the sublease, list the property, and collect the spread — while everyone else is waiting for the 'right time' to start.\n\n[8 seconds]\n\nReal estate assignment + Airbnb arbitrage = the 1% formula. 🤖🏠\n\nAssign the skyscraper deal. Collect the fee. Roll it into the Airbnb portfolio. Compound. Repeat.\n\nJoin the Club — link below. 🔗 createaiprofit.com",

  "'Power is not given — it is taken.' — Machiavelli\n\nToday? He'd take the passive income play that requires zero capital and maximum leverage. The Airbnb sublease model: you don't need to own anything.\n\n[8 seconds]\n\n$3k passive last week. Zero capital in. 💸\n\nAirbnb sublease model: you don't need to own anything. You need the right contract, the right market, and the right system. All three are inside.\n\nClub Vault. DM or comment 'The Don' for The Don discount. 🔗 createaiprofit.com/vault",

  "'The ends justify the means.' — Machiavelli\n\nToday? He'd use every legal leverage play available. The sublease model changed the game: no mortgage, no ownership, no capital required. Just a lease and a listing.\n\n[8 seconds]\n\nThe sublease model changed my life. 🔑\n\nNo mortgage. No ownership. No capital required. Just a lease agreement, a listing, and a system that runs while you sleep.\n\nFull walkthrough — link in bio. 🔗 createaiprofit.com",
];

// ─── SEED POST QUEUE HELPER ───────────────────────────────────────────────────
const BOT_CAPTIONS = [
  // Lifestyle / flex
  "Woke up to another passive income notification 💰 — the system works while you sleep",
  "Closed another Airbnb deal from the pool 🏊‍♂️ — location independence is real",
  "My portfolio just hit a new ATH 📈 — 3 years of discipline paying off",
  "Penthouse view, laptop open, no alarm clock 🌅 — this is what freedom looks like",
  "Just landed in Monaco 🇲🇨 — third trip this month, all covered by passive income",
  "The Rolex isn't a flex — it's a reminder that time is the only real currency ⌚",
  "Yacht day with the team 🛥️ — we built this from zero, no inheritance, no shortcuts",
  "Another 5-figure month in the books 📊 — the blueprint is simple, execution is everything",
  "Dubai at sunset hits different when you own the view 🌆",
  "Closed a $2.1M assignment deal this week 🏢 — skyscrapers only, floors 50+",
  // Mindset / Machiavelli
  "The lion cannot protect himself from traps, and the fox cannot defend himself from wolves 🦊 — be both",
  "Power is not given — it is taken by those who understand the game 👑",
  "Opportunities multiply as they are seized 🎯 — stop waiting for permission",
  "The first method for estimating the intelligence of a ruler is to look at the men around him 🔍",
  "Never attempt to win by force what can be won by deception 🃏 — Machiavelli knew",
  "It is better to be feared than loved, if you cannot be both 💎 — build accordingly",
  "Men judge generally more by the eye than by the hand 👁️ — optics are strategy",
  "The wise man does at once what the fool does finally 🧠 — speed is leverage",
  "Fortune favors the bold — but preparation makes boldness possible 🏆",
  "A prince never lacks legitimate reasons to break his promise 📜 — adapt or die",
  // Wealth building
  "Real estate + AI + automation = the new 1% formula 🤖🏠",
  "Your 9-5 makes someone else rich — your side hustle makes you free 💸",
  "The Airbnb arbitrage game is still wide open if you know the right markets 🗺️",
  "Stack silent. Move loud. Let the results speak 🔇",
  "40% of every deal goes back to the community — we eat together 🤝",
  "The algorithm rewards consistency — so does compound interest 📊",
  "Three income streams minimum — anything less is fragile 🌊",
  "Your network is your net worth — choose your room wisely 🚪",
  "The 1% don't work harder — they build better systems ⚙️",
  "Passive income isn't lazy — it's leverage 💡",
  // Airbnb / Real estate
  "Just listed a new short-term rental in Miami — $4,200/month cash flow 🌴",
  "Airbnb arbitrage: rent for $2k, list for $5k — the math is simple 🧮",
  "Property number 7 is live 🏡 — no mortgage, no ownership, just cash flow",
  "The sublease model changed my life — no capital needed to start 🔑",
  "Skyscraper assignments: the highest-margin real estate play nobody talks about 🏙️",
  // Motivation
  "If you're still trading time for money in 2025, we need to talk 📱",
  "The cage is comfortable — that's why most people stay in it 🔓",
  "10 million men need to escape the 9-5 cage — this app is the key 🗝️",
  "Free 10 million men from the cage — that's the mission 🎯",
  "You don't need more hours — you need better systems ⚡",
];

async function seedPostQueue(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  count: number
): Promise<number> {
  const activeBots = await db.select({ id: botAccounts.id })
    .from(botAccounts)
    .where(eq(botAccounts.active, true))
    .limit(1000);

  if (activeBots.length === 0) return 0;

  const now = new Date();
  const entries = [];

  for (let i = 0; i < count; i++) {
    const bot = activeBots[Math.floor(Math.random() * activeBots.length)];
    // Spread posts over the next 24 hours
    const minutesAhead = Math.floor(Math.random() * 24 * 60);
    const scheduledAt = new Date(now.getTime() + minutesAhead * 60 * 1000);
    entries.push({
      botId: bot.id,
      caption: pick(BOT_CAPTIONS),
      scheduledAt,
      posted: false,
    });
  }

  // Insert in batches of 100
  let seeded = 0;
  for (let i = 0; i < entries.length; i += 100) {
    const batch = entries.slice(i, i + 100);
    await db.insert(botPostQueue).values(batch);
    seeded += batch.length;
  }

  return seeded;
}
