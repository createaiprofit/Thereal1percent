import { z } from "zod";
import { router, protectedProcedure } from "../_core/trpc";
import { TRPCError } from "@trpc/server";
import { getDb } from "../db";
import {
  deals,
  callLogs,
  botPerformance,
  warRoomAlerts,
} from "../../drizzle/schema";
import { eq, desc, sql, and, gte } from "drizzle-orm";

// Admin guard middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const warRoomRouter = router({
  // ─── DEALS ────────────────────────────────────────────────────────────────

  deals: {
    list: adminProcedure
      .input(
        z.object({
          stage: z
            .enum(["cold", "pitched", "negotiating", "assigned", "closed", "lost"])
            .optional(),
          limit: z.number().min(1).max(200).default(50),
          offset: z.number().min(0).default(0),
        })
      )
      .query(async ({ input }) => {
        const conditions = input.stage ? [eq(deals.stage, input.stage)] : [];
        const db = await getDb();
        if (!db) return [];
        const rows = await db
          .select()
          .from(deals)
          .where(conditions.length ? and(...conditions) : undefined)
          .orderBy(desc(deals.updatedAt))
          .limit(input.limit)
          .offset(input.offset);
        return rows;
      }),

    create: adminProcedure
      .input(
        z.object({
          ownerName: z.string().min(1),
          propertyAddress: z.string().min(1),
          city: z.string().min(1),
          floors: z.number().optional(),
          estimatedValue: z.string().optional(),
          feeProjected: z.string().optional(),
          assignedAgent: z.string().optional(),
          financeNeeded: z.boolean().default(false),
          financeProvider: z.string().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        const [result] = await db.insert(deals).values({
          ownerName: input.ownerName,
          propertyAddress: input.propertyAddress,
          city: input.city,
          floors: input.floors,
          estimatedValue: input.estimatedValue,
          feeProjected: input.feeProjected,
          assignedAgent: input.assignedAgent,
          financeNeeded: input.financeNeeded,
          financeProvider: input.financeProvider,
          notes: input.notes,
          stage: "cold",
        });

        // Fire alert
        await db.insert(warRoomAlerts).values({
          type: "deal_milestone",
          title: "New Deal Added",
          message: `${input.ownerName} — ${input.city} (${input.floors ?? "?"}F) added to pipeline`,
          severity: "info",
        });

        return { success: true };
      }),

    updateStage: adminProcedure
      .input(
        z.object({
          id: z.number(),
          stage: z.enum(["cold", "pitched", "negotiating", "assigned", "closed", "lost"]),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        const updates: Partial<typeof deals.$inferInsert> = {
          stage: input.stage,
        };
        if (input.notes) updates.notes = input.notes;
        if (input.stage === "assigned") updates.assignedAt = new Date();
        if (input.stage === "closed") updates.closedAt = new Date();

        await db.update(deals).set(updates).where(eq(deals.id, input.id));

        if (input.stage === "closed") {
          const [deal] = await db.select().from(deals).where(eq(deals.id, input.id));
          await db.insert(warRoomAlerts).values({
            type: "deal_milestone",
            title: "Deal Closed!",
            message: `${deal.ownerName} — ${deal.city} closed. Fee: $${deal.feeCollected ?? deal.feeProjected ?? "TBD"}`,
            severity: "info",
            relatedDealId: input.id,
          });
        }

        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        await db.delete(deals).where(eq(deals.id, input.id));
        return { success: true };
      }),

    stats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return null;
      const [totals] = await db
        .select({
          totalDeals: sql<number>`COUNT(*)`,
          totalFeesProjected: sql<string>`SUM(fee_projected)`,
          totalFeesCollected: sql<string>`SUM(fee_collected)`,
          closedDeals: sql<number>`SUM(CASE WHEN stage = 'closed' THEN 1 ELSE 0 END)`,
          assignedDeals: sql<number>`SUM(CASE WHEN stage = 'assigned' THEN 1 ELSE 0 END)`,
          activeDeals: sql<number>`SUM(CASE WHEN stage NOT IN ('closed','lost') THEN 1 ELSE 0 END)`,
        })
        .from(deals);
      return totals;
    }),
  },

  // ─── CALL LOGS ────────────────────────────────────────────────────────────

  calls: {
    list: adminProcedure
      .input(
        z.object({
          dealId: z.number().optional(),
          botName: z.string().optional(),
          limit: z.number().min(1).max(200).default(100),
          offset: z.number().min(0).default(0),
        })
      )
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const conditions = [];
        if (input.dealId) conditions.push(eq(callLogs.dealId, input.dealId));
        if (input.botName) conditions.push(eq(callLogs.botName, input.botName));

        const rows = await db
          .select()
          .from(callLogs)
          .where(conditions.length ? and(...conditions) : undefined)
          .orderBy(desc(callLogs.calledAt))
          .limit(input.limit)
          .offset(input.offset);
        return rows;
      }),

    log: adminProcedure
      .input(
        z.object({
          dealId: z.number().optional(),
          botName: z.string().min(1),
          callType: z.enum(["cold_call", "email", "follow_up", "voicemail"]),
          outcome: z.enum([
            "no_answer",
            "voicemail",
            "interested",
            "not_interested",
            "callback",
            "pitched",
            "assigned",
          ]),
          duration: z.number().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        await db.insert(callLogs).values({
          dealId: input.dealId,
          botName: input.botName,
          callType: input.callType,
          outcome: input.outcome,
          duration: input.duration,
          notes: input.notes,
        });

        // Alert if deal moved to assigned
        if (input.outcome === "assigned" && input.dealId) {
          await db.insert(warRoomAlerts).values({
            type: "deal_milestone",
            title: "Deal Assigned!",
            message: `${input.botName} closed an assignment`,
            severity: "info",
            relatedDealId: input.dealId,
          });
        }

        return { success: true };
      }),

    todayStats: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return null;
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const [stats] = await db
        .select({
          totalCalls: sql<number>`COUNT(*)`,
          interested: sql<number>`SUM(CASE WHEN outcome = 'interested' THEN 1 ELSE 0 END)`,
          pitched: sql<number>`SUM(CASE WHEN outcome = 'pitched' THEN 1 ELSE 0 END)`,
          assigned: sql<number>`SUM(CASE WHEN outcome = 'assigned' THEN 1 ELSE 0 END)`,
          noAnswer: sql<number>`SUM(CASE WHEN outcome = 'no_answer' THEN 1 ELSE 0 END)`,
        })
        .from(callLogs)
        .where(gte(callLogs.calledAt, today));

      return stats;
    }),
  },

  // ─── BOT PERFORMANCE ──────────────────────────────────────────────────────

  bots: {
    performance: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return [];
      const rows = await db
        .select()
        .from(botPerformance)
        .orderBy(desc(botPerformance.feesGenerated));
      return rows;
    }),

    upsertSnapshot: adminProcedure
      .input(
        z.object({
          botName: z.string().min(1),
          zone: z.string().optional(),
          callsToday: z.number().default(0),
          callsWeek: z.number().default(0),
          pitchedCount: z.number().default(0),
          assignedCount: z.number().default(0),
          feesGenerated: z.string().default("0.00"),
          topMarket: z.string().optional(),
          alertFlag: z.boolean().default(false),
        })
      )
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        const conversionRate =
          input.callsWeek > 0
            ? ((input.assignedCount / input.callsWeek) * 100).toFixed(2)
            : "0.00";

        // Check if snapshot exists for today
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const existing = await db
          .select()
          .from(botPerformance)
          .where(
            and(
              eq(botPerformance.botName, input.botName),
              gte(botPerformance.snapshotDate, today)
            )
          )
          .limit(1);

        if (existing.length > 0) {
          await db
            .update(botPerformance)
            .set({ ...input, conversionRate })
            .where(eq(botPerformance.id, existing[0].id));
        } else {
          await db.insert(botPerformance).values({ ...input, conversionRate });
        }

        // Alert if bot is flagged low
        if (input.alertFlag) {
          await db.insert(warRoomAlerts).values({
            type: "bot_low",
            title: `${input.botName} Below Threshold`,
            message: `${input.botName} only made ${input.callsToday} calls today — check script`,
            severity: "warning",
          });
        }

        return { success: true };
      }),
  },

  // ─── ALERTS ───────────────────────────────────────────────────────────────

  alerts: {
    list: adminProcedure
      .input(
        z.object({
          unreadOnly: z.boolean().default(false),
          limit: z.number().min(1).max(100).default(30),
        })
      )
      .query(async ({ input }) => {
        const db = await getDb();
        if (!db) return [];
        const conditions = input.unreadOnly ? [eq(warRoomAlerts.read, false)] : [];
        const rows = await db
          .select()
          .from(warRoomAlerts)
          .where(conditions.length ? and(...conditions) : undefined)
          .orderBy(desc(warRoomAlerts.createdAt))
          .limit(input.limit);
        return rows;
      }),

    markRead: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
        await db
          .update(warRoomAlerts)
          .set({ read: true })
          .where(eq(warRoomAlerts.id, input.id));
        return { success: true };
      }),

    markAllRead: adminProcedure.mutation(async () => {
      const db = await getDb();
      if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "DB unavailable" });
      await db.update(warRoomAlerts).set({ read: true });
      return { success: true };
    }),

    unreadCount: adminProcedure.query(async () => {
      const db = await getDb();
      if (!db) return 0;
      const [result] = await db
        .select({ count: sql<number>`COUNT(*)` })
        .from(warRoomAlerts)
        .where(eq(warRoomAlerts.read, false));
      return result.count;
    }),
  },

  // ─── ANALYTICS OVERVIEW ───────────────────────────────────────────────────

  overview: adminProcedure.query(async () => {
    const db = await getDb();
    if (!db) return null;
    const [dealStats] = await db
      .select({
        totalDeals: sql<number>`COUNT(*)`,
        totalFeesProjected: sql<string>`COALESCE(SUM(fee_projected), 0)`,
        totalFeesCollected: sql<string>`COALESCE(SUM(fee_collected), 0)`,
        closedDeals: sql<number>`SUM(CASE WHEN stage = 'closed' THEN 1 ELSE 0 END)`,
        activeDeals: sql<number>`SUM(CASE WHEN stage NOT IN ('closed','lost') THEN 1 ELSE 0 END)`,
      })
      .from(deals);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [callStats] = await db
      .select({
        callsToday: sql<number>`COUNT(*)`,
        assignedToday: sql<number>`SUM(CASE WHEN outcome = 'assigned' THEN 1 ELSE 0 END)`,
        interestedToday: sql<number>`SUM(CASE WHEN outcome = 'interested' THEN 1 ELSE 0 END)`,
      })
      .from(callLogs)
      .where(gte(callLogs.calledAt, today));

    const unreadAlerts = await db
      .select({ count: sql<number>`COUNT(*)` })
      .from(warRoomAlerts)
      .where(eq(warRoomAlerts.read, false));

    const topBots = await db
      .select()
      .from(botPerformance)
      .orderBy(desc(botPerformance.feesGenerated))
      .limit(5);

    return {
      deals: dealStats,
      calls: callStats,
      unreadAlerts: unreadAlerts[0].count,
      topBots,
    };
  }),
});
