/**
 * Social Media Auto-Posting Layer
 * Handles posting to Instagram (Meta Graph API), TikTok (Content Posting API), YouTube (Data API v3)
 * 5-6 posts/day per platform, random avatar rotation
 */

// ─── TYPES ────────────────────────────────────────────────────────────────────

export interface SocialPost {
  avatarId: string;
  avatarName: string;
  caption: string;
  videoUrl?: string;
  imageUrl?: string;
  affiliateLink: string;
  platform: "instagram" | "tiktok" | "youtube";
}

export interface PostResult {
  platform: string;
  success: boolean;
  postId?: string;
  error?: string;
}

// ─── INSTAGRAM (META GRAPH API) ───────────────────────────────────────────────

/**
 * Post a video/image to Instagram via Meta Graph API
 * Requires: IG_ACCESS_TOKEN, IG_USER_ID
 * Scopes needed: instagram_basic, instagram_content_publish, pages_read_engagement
 */
export async function postToInstagram(post: SocialPost): Promise<PostResult> {
  const accessToken = process.env.IG_ACCESS_TOKEN;
  const userId = process.env.IG_USER_ID;

  if (!accessToken || !userId) {
    return { platform: "instagram", success: false, error: "Missing IG_ACCESS_TOKEN or IG_USER_ID" };
  }

  try {
    const mediaType = post.videoUrl ? "REELS" : "IMAGE";
    const mediaUrl = post.videoUrl || post.imageUrl;

    if (!mediaUrl) {
      return { platform: "instagram", success: false, error: "No media URL provided" };
    }

    // Step 1: Create media container
    const containerParams = new URLSearchParams({
      access_token: accessToken,
      caption: `${post.caption}\n\n${post.affiliateLink}\n\n#CreateAIProfit #CAP #PassiveIncome #AIProfit #LuxuryLifestyle`,
      media_type: mediaType,
    });

    if (post.videoUrl) {
      containerParams.set("video_url", post.videoUrl);
      containerParams.set("share_to_feed", "true");
    } else if (post.imageUrl) {
      containerParams.set("image_url", post.imageUrl);
    }

    const containerRes = await fetch(
      `https://graph.instagram.com/v18.0/${userId}/media`,
      { method: "POST", body: containerParams }
    );
    const container = await containerRes.json() as { id?: string; error?: { message: string } };

    if (!container.id) {
      return { platform: "instagram", success: false, error: container.error?.message || "Failed to create container" };
    }

    // Step 2: Wait for video processing (reels take ~30s)
    if (post.videoUrl) {
      await new Promise(r => setTimeout(r, 30000));
    }

    // Step 3: Publish the container
    const publishRes = await fetch(
      `https://graph.instagram.com/v18.0/${userId}/media_publish`,
      {
        method: "POST",
        body: new URLSearchParams({
          access_token: accessToken,
          creation_id: container.id,
        }),
      }
    );
    const published = await publishRes.json() as { id?: string; error?: { message: string } };

    if (published.id) {
      return { platform: "instagram", success: true, postId: published.id };
    }
    return { platform: "instagram", success: false, error: published.error?.message || "Publish failed" };

  } catch (err) {
    return { platform: "instagram", success: false, error: String(err) };
  }
}

// ─── TIKTOK (CONTENT POSTING API) ─────────────────────────────────────────────

/**
 * Post a video to TikTok via Content Posting API
 * Requires: TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET (for client credentials)
 * Or: TIKTOK_ACCESS_TOKEN, TIKTOK_OPEN_ID (for user-authorized posting)
 * Scopes needed: video.upload, video.publish
 */
export async function postToTikTok(post: SocialPost): Promise<PostResult> {
  // Prefer user access token if available, fall back to client credentials
  let accessToken = process.env.TIKTOK_ACCESS_TOKEN;

  // If no user access token, get one via client credentials
  if (!accessToken) {
    const clientKey = process.env.TIKTOK_CLIENT_KEY;
    const clientSecret = process.env.TIKTOK_CLIENT_SECRET;
    if (!clientKey || !clientSecret) {
      return { platform: "tiktok", success: false, error: "Missing TIKTOK_CLIENT_KEY or TIKTOK_CLIENT_SECRET" };
    }
    try {
      const tokenRes = await fetch("https://open.tiktokapis.com/v2/oauth/token/", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_key: clientKey,
          client_secret: clientSecret,
          grant_type: "client_credentials",
        }),
      });
      const tokenData = await tokenRes.json() as { access_token?: string; error?: string };
      if (!tokenData.access_token) {
        return { platform: "tiktok", success: false, error: `Token error: ${tokenData.error || "no access_token"}. Note: user authorization required for video.publish scope — provide TIKTOK_ACCESS_TOKEN from OAuth flow.` };
      }
      accessToken = tokenData.access_token;
    } catch (err) {
      return { platform: "tiktok", success: false, error: `Token fetch failed: ${String(err)}` };
    }
  }

  if (!accessToken) {
    return { platform: "tiktok", success: false, error: "Could not obtain TikTok access token" };
  }

  if (!post.videoUrl) {
    return { platform: "tiktok", success: false, error: "TikTok requires a video URL" };
  }

  try {
    // Step 1: Initialize upload
    const initRes = await fetch(
      "https://open.tiktokapis.com/v2/post/publish/video/init/",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json; charset=UTF-8",
        },
        body: JSON.stringify({
          post_info: {
            title: `${post.caption.slice(0, 150)} #CreateAIProfit #CAP #PassiveIncome`,
            privacy_level: "PUBLIC_TO_EVERYONE",
            disable_duet: false,
            disable_comment: false,
            disable_stitch: false,
            video_cover_timestamp_ms: 1000,
          },
          source_info: {
            source: "PULL_FROM_URL",
            video_url: post.videoUrl,
          },
        }),
      }
    );
    const initData = await initRes.json() as {
      data?: { publish_id?: string; upload_url?: string };
      error?: { code: string; message: string };
    };

    if (initData.error?.code && initData.error.code !== "ok") {
      return { platform: "tiktok", success: false, error: initData.error.message };
    }

    const publishId = initData.data?.publish_id;
    if (!publishId) {
      return { platform: "tiktok", success: false, error: "No publish_id returned" };
    }

    return { platform: "tiktok", success: true, postId: publishId };

  } catch (err) {
    return { platform: "tiktok", success: false, error: String(err) };
  }
}

// ─── YOUTUBE (DATA API v3) ─────────────────────────────────────────────────────

/**
 * Upload a video to YouTube via Data API v3
 * Requires: YOUTUBE_ACCESS_TOKEN
 * Scopes needed: https://www.googleapis.com/auth/youtube.upload
 */
export async function postToYouTube(post: SocialPost): Promise<PostResult> {
  const accessToken = process.env.YOUTUBE_ACCESS_TOKEN;

  if (!accessToken) {
    return { platform: "youtube", success: false, error: "Missing YOUTUBE_ACCESS_TOKEN" };
  }

  if (!post.videoUrl) {
    return { platform: "youtube", success: false, error: "YouTube requires a video URL" };
  }

  try {
    // Fetch the video bytes from the URL
    const videoRes = await fetch(post.videoUrl);
    if (!videoRes.ok) {
      return { platform: "youtube", success: false, error: "Could not fetch video from URL" };
    }
    const videoBuffer = await videoRes.arrayBuffer();

    // Step 1: Insert metadata
    const metadataRes = await fetch(
      "https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json; charset=UTF-8",
          "X-Upload-Content-Type": "video/mp4",
          "X-Upload-Content-Length": String(videoBuffer.byteLength),
        },
        body: JSON.stringify({
          snippet: {
            title: `${post.avatarName} — ${post.caption.slice(0, 80)} | Create AI Profit`,
            description: `${post.caption}\n\n${post.affiliateLink}\n\n#CreateAIProfit #CAP #PassiveIncome #AIProfit #LuxuryLifestyle #WealthMindset`,
            tags: ["CreateAIProfit", "CAP", "PassiveIncome", "AIProfit", "LuxuryLifestyle", "WealthMindset", "FinancialFreedom"],
            categoryId: "22", // People & Blogs
          },
          status: {
            privacyStatus: "public",
            selfDeclaredMadeForKids: false,
          },
        }),
      }
    );

    const uploadUrl = metadataRes.headers.get("Location");
    if (!uploadUrl) {
      return { platform: "youtube", success: false, error: "No resumable upload URL returned" };
    }

    // Step 2: Upload video bytes
    const uploadRes = await fetch(uploadUrl, {
      method: "PUT",
      headers: {
        "Content-Type": "video/mp4",
        "Content-Length": String(videoBuffer.byteLength),
      },
      body: videoBuffer,
    });

    const uploadData = await uploadRes.json() as { id?: string; error?: { message: string } };

    if (uploadData.id) {
      return { platform: "youtube", success: true, postId: uploadData.id };
    }
    return { platform: "youtube", success: false, error: uploadData.error?.message || "Upload failed" };

  } catch (err) {
    return { platform: "youtube", success: false, error: String(err) };
  }
}

// ─── MULTI-PLATFORM DISPATCHER ────────────────────────────────────────────────

/**
 * Post to all three platforms simultaneously
 */
export async function postToAllPlatforms(post: SocialPost): Promise<PostResult[]> {
  const results = await Promise.allSettled([
    postToInstagram({ ...post, platform: "instagram" }),
    postToTikTok({ ...post, platform: "tiktok" }),
    postToYouTube({ ...post, platform: "youtube" }),
  ]);

  return results.map(r => r.status === "fulfilled" ? r.value : {
    platform: "unknown",
    success: false,
    error: r.reason as string,
  });
}
